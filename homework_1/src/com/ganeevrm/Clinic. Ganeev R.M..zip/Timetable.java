package com.ganeevrm;

public class Timetable {
}
