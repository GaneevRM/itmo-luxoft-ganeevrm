package com.ganeevrm;

import com.ganeevrm.person.Doctor;
import com.ganeevrm.person.Patient;

public class Main {

    public static void main(String[] args) {
        Doctor doctor = new Doctor("Виктор", "Круглов", new Timetable());
        Doctor doctor2 = new Doctor("Лариса", "Коротких", new Timetable());
        Patient patient = new Patient("Мария", "Сорокина", new Card("12.07.2023", doctor));
        Patient patient2 = new Patient("Игорь", "Мишкин", new Card("25.09.2023", doctor2));


        System.out.println("Пациент - " + patient.getFirstName() + " " + patient.getSurname());
        System.out.println("Карта - " + patient.getCard().getNumberCard());
        System.out.println("Врач - " + patient.getCard().getDoctor().getFirstName());

        System.out.println("------------------------------------------------------");

        System.out.println("Пациент - " + patient2.getFirstName() + " " + patient2.getSurname());
        System.out.println("Карта - " + patient2.getCard().getNumberCard());
        System.out.println("Врач - " + patient2.getCard().getDoctor().getFirstName());
    }
}
